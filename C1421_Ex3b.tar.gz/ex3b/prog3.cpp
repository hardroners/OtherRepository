/* prog3.cpp exemple d'utilisation de la classe vehicule */

#include "Vehic.h"

int main(int N, char *P[])
{
Vehic V1, V2((char*)"Vaisseau spacial"), V3((char*)"V3",90,4);
     V1.affiche((char*)"V1");
     V2.affiche((char*)"V2");
     V3.affiche((char*)"V3");
     V1.modif((char*)"vehicule leger",70,2);
     V1.affiche((char*)"V1 apres");
     return 0;
}

