/* Vehic.cpp : code de la classe vehicule */
#include <iostream>
#include <string.h>
#include "Vehic.h"

void Vehic::maj(char * N, int v, int nb)
{
   strncpy(nom,N, LNOM);
   nom[LNOM]='\0';
   vitesse = v;
   nbp = nb;
}

Vehic::Vehic (void) { maj((char*)"",VIT_DEF,NBP_DEF); } // les constructeurs
Vehic::Vehic (char * n) { maj(n,VIT_DEF,NBP_DEF); }
Vehic::Vehic (char * n, int v, int nb) { maj(n,v,nb); }

void Vehic::modif(char* n, int vit, int nb) { maj(n,vit,nb); }

void Vehic::affiche(char * M)
{
   cout<<M<<" : Vehicule '"<<nom<<"' vitesse = "<<vitesse<<" nbp="<<nbp<<endl;
}

