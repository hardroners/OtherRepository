/* Vehic.h : header file de la classe vehicule */

#define LNOM 127     /* longueur maximale du nom */
#define VIT_DEF 0    // vitesse par defaut
#define NBP_DEF 1    // nb de personnes par defaut
using namespace std; // utilisation de l'espace des noms standard

class Vehic {
    char nom[LNOM+1];
    int vitesse; /* en km/h */
    int nbp; /* nb de passager */
    // les methodes privees
    void maj(char * nom, int vitesse, int nbpersonne);
public:
    Vehic (void);
    Vehic (char * nom);
    Vehic (char * nom, int vitesse, int nbpersonne);
    void modif(char* n, int vit, int nb);
    void affiche(char * M);
};


